global.justScrewed = 0;
global.justNailed = 0;