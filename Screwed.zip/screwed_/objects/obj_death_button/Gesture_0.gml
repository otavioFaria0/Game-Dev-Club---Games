game_restart();
