screwedBefore = false;
global.justNailed += 1;

sinking = false;