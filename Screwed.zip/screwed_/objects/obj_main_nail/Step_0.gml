
var _tocando = place_meeting(x, y - 4, obj_player2);


var _atacando = false;

if (instance_exists(obj_player2))
{
    _atacando = obj_player2.spinMode
        && obj_player2.sprite_index == spr_player2_attack
        && floor(obj_player2.image_index) == 2;
}


if (_tocando && _atacando && !sinking)
{
    sinking = true;

    if (y < ystart + 64)
    {
        audio_play_sound(snd_bounce, 1, false);

       
        y = ystart + 64;
    }

    if (y >= ystart + 64 && !screwedBefore)
    {
        global.justNailed -= 1;
        screwedBefore = true;
    }
}


if (!_atacando)
{
    sinking = false;
}