yStart = y;
opendoor = false;