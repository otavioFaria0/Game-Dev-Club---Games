global.justScrewed =0;
