yStart = y;
opendoor = false;