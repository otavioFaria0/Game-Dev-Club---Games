game_restart();
